MONGODB_SETTINGS = {
    'db':'webharjoitus4',
    'host':'localhost',
    'port':27017
}